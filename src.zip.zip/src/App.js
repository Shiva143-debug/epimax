import { BrowserRouter, Routes, Route } from "react-router-dom"
import "bootstrap/dist/css/bootstrap.min.css"
import Task from "./Task"

function App() {
  return (
    <BrowserRouter>
      <Routes>
      <Route path="/" element={<Task />}></Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App